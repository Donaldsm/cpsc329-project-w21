<template>
  <div class="text-left pl-16">
    <h1 class="text-4xl font-extrabold">Congrats! You Scored: {{this.score}}</h1>
    <h1 class="text-2xl font-extrabold pb-12">
      But.. what does that really mean..
    </h1>
    <h1 class="text-2xl font-extrabold">
      If.. you scored from 0 to 15: You are a computer Wizard! Nothing can phase
      you.
    </h1>
    <h1 class="text-2xl font-extrabold">
      If.. you scored from 16 to 30: You are the average joe! Normal computer
      users should score here! Nothing to be ashamed of!
    </h1>
    <h1 class="text-2xl font-extrabold">
      If.. you scored from 31 to 45: Ooo... little lower than average, but still
      ok..
    </h1>
    <h1 class="text-2xl font-extrabold pb-12">
      If.. you scored from 46 onward: Oh no... please take a look below to see
      what you did wrong.
    </h1>

    <h1 class="text-2xl font-extrabold pb-6">
      Now did you find anything unusual about the quiz?
    </h1>

    <h1 class="text-2xl font-extrabold pb-12">
      Other than regular questions, we also threw in some traps! Here are the
      answers to the questions as well as the traps:
    </h1>
    <div class="pb-16">
      <h1 class="text-2xl font-extrabold pb-3">Question 1:</h1>
      <p class="text-xl font-bold">
        We asked you a bunch of different questions, did some seem a little too
        personal for an online quiz to be asking?
      </p>
      <p class="text-xl font-bold">
        If you answered anything for: First Name, Last Name, Phone number,
        Birthday and City. You gained 1 point for each
      </p>
    </div>
    <div class="pb-16">
      <h1 class="text-2xl font-extrabold pb-3">Question 2:</h1>
      <p class="text-xl font-bold">
        We asked you for a bunch a passwords, what did you think a strong
        password should be?
      </p>
      <p class="text-xl font-bold">
        If you answered a password which included anything related to what you
        told us in question 1, you gained a point.
      </p>
    </div>
    <div class="pb-16">
      <h1 class="text-2xl font-extrabold pb-3">Question 3:</h1>
      <p class="text-xl font-bold">
        Taking a look at the comic, what do you think the correct answer is?
      </p>
      <p class="text-xl font-bold">
        Its definitely NO! you never share private keys. No traps on this
        question, just a simple yes or no.
      </p>
    </div>
    <div class="pb-16">
      <h1 class="text-2xl font-extrabold pb-3">Question 4:</h1>
      <p class="text-xl font-bold">
        We asked you to simply go to the next question. Now do you remember it
        asking you to update your flash player?
      </p>
      <p class="text-xl font-bold">
        If you clicked YES to updating your flash player, you got a point!
        Remember if something does not seem right on the internet, the best
        course of action is to just say NO!
      </p>
      <p class="text-xl font-bold">
        For the second part of the question, just remember to look for details
        before clicking, if you clicked the wrong button, you got a point as
        well.
      </p>
    </div>
    <div class="pb-16">
      <h1 class="text-2xl font-extrabold pb-3">Question 5:</h1>
      <p class="text-xl font-bold">
        Who said this was a closed book quiz! The 1s and 0s of this question
        basically translate to: "Please do not touch this button"
      </p>
      <p class="text-xl font-bold">
        If you clicked the "click me" button, you gained a point for each time
        you clicked it! Remember, if you do not know about something or unsure
        about it, just google it! Nobody says you gotta face it alone!
      </p>
    </div>
    <div class="pb-16">
      <h1 class="text-2xl font-extrabold pb-3">Question 6:</h1>
      <p class="text-xl font-bold">
        We gave you 2 emails, could you tell which one is the phishing email?
      </p>
      <p class="text-xl font-bold">
        If you choose BOTH you are CORRECT! Remember to take a look at the small
        details such a the sender email and spelling before clicking any links!
        You gained a point if you did not get the right answer.
      </p>
    </div>
    <div class="pb-16">
      <h1 class="text-2xl font-extrabold pb-3">Question 7:</h1>
      <p class="text-xl font-bold">
        You had to figure out how to play the encryption game for this question.
        Did you ever win?
      </p>
      <p class="text-xl font-bold">
        This question demonstrates how strong encryption keys can be these days,
        you acted as a hacker for a little bit by trying to find 2 matching
        keys. In reality, it is quite impossible to do, thus you gained a point
        for every time you tried.
      </p>
    </div>
    <div class="pb-16">
      <h1 class="text-2xl font-extrabold pb-3">Question 8:</h1>
      <p class="text-xl font-bold">
        Have you ever seen this page on the internet?
      </p>
      <p class="text-xl font-bold">
        This question demonstrates how modern broswers these days protect you
        from malicious sites on the web, and you should TRUST these warnings! If
        you clicked procced, you gained a point.
      </p>
    </div>

    <h1 class="text-4xl font-extrabold p-12">
      Thats it! Hope you had fun doing this quiz! But more importantly, we hope
      you learnt something about computer security! Stay safe out there my
      friend!
    </h1>
  </div>
</template>
<script lang='ts'>
import {Component,Prop, Vue} from 'vue-property-decorator';

@Component({})
export default class End extends Vue{
// @ts-ignore
@Prop() score: number;

}
</script>
