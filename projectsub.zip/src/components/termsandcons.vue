<template>
    <div>
        <h1 class = "text-3xl font-extrabold">WELL WELL WELL... WE HAVE A SMART COOKIE HERE!</h1>

        <h1 class = "text-2xl font-extrabold">Since you are here, why don't we let you in on a little secret...</h1>

        <h1 class = "text-xl font-extrabold">Be careful on the quiz... as it might not be as straightforward as you might think...</h1>

        <h1 class = "text-l font-extrabold">If something seems... fishy... best to not touch it ya? </h1>

        <h1 class = "text-xl font-extrabold pb-6">GOOD LUCK!</h1>

        <router-link to='/cpsc329quiz/'>
            <button type = "button" class = " max-w-xs bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mx-auto " >Go Back</button>
        </router-link>
    </div>
</template>